
<?php include "plantillas/encabezado.php"; ?>

		<br>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
				<h4>Menu Principal Sistema Prestamos</h4>
				</div>
			</div>
		</div>

		<hr>
		<!--label for="">Cliente: </label><select name="selCliente" id="selCliente">
			<option value="0">Seleccione...</option></select-->
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<a href="CatalogoClientes.php" class="btn btn-primary mt-4">Catalogo de Clientes</a>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<a href="RegistroPrestamos.php" class="btn btn-primary mt-4">Prestamos</a>
				</div>
			</div>
		</div>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		<hr>
		<div class="container">
			<a href="instalar.php" class="text">Preparar la BD Prestamos</a>
		</div>

<?php include "plantillas/piepagina.php"; ?>